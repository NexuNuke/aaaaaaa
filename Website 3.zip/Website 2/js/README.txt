A Pen created at CodePen.io. You can find this one at https://codepen.io/derekmorash/pen/NjBvdX.

 Lazy load images by initially loading a low res version and then replacing it with a higher res version once the page is done loading.

I wrote tutorial on this technique, [Simple Image Lazy Loading](https://codepen.io/derekmorash/post/simple-image-lazy-loading)